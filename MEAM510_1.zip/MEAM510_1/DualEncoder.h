#ifndef DUAL_ENCODER_H
#define DUAL_ENCODER_H

#include <Arduino.h>

class DualEncoder {
public:
  // Constructor
  DualEncoder(uint8_t pinAR, uint8_t pinBR, uint8_t pinAL, uint8_t pinBL);
  
  // Initialize the encoders
  void begin();
  
  // Get encoder counts
  int32_t getCountR();
  int32_t getCountL();
  
  // Reset encoder counts
  void resetCountR();
  void resetCountL();
  
  // Set RPM measurement parameters
  void setRpmUpdateInterval(uint32_t intervalMicros) { rpmUpdateInterval = intervalMicros; }
  void setGearRatio(uint16_t ratio) { gearRatio = ratio; }
  void setEncoderCPR(uint16_t cpr) { encoderCPR = cpr; }
  
  // Start/stop RPM measurement
  void startRpmMeasurement();
  void stopRpmMeasurement();
  
  // Get RPM values
  float getRpmR();
  float getRpmL();
  
  // This function is public but should only be called from a timer
  void calculateRpm();

private:
  // Pin definitions
  uint8_t pinAR, pinBR;
  uint8_t pinAL, pinBL;
  
  // Encoder counts
  volatile int32_t encoderCountR = 0;
  volatile int32_t encoderCountL = 0;
  
  // Last count values for RPM calculation
  volatile int32_t lastCountR = 0;
  volatile int32_t lastCountL = 0;
  
  // RPM values
  volatile float rpmR = 0.0;
  volatile float rpmL = 0.0;
  
  // RPM calculation parameters
  uint32_t lastRpmUpdate = 0;
  uint32_t rpmUpdateInterval = 100000; // 100ms in microseconds (10Hz)
  uint16_t gearRatio = 30;   // Default gear ratio
  uint16_t encoderCPR = 64;  // Default encoder counts per revolution
  
  // Timer for ESP32
  hw_timer_t* timer = nullptr;
  int timerNumber = 0;
  
  // Encoder processing function
  void updateFromISR(bool isRight, bool isA);
  
  // Static members
  static DualEncoder* instance;
  
  // ISR handlers
  static void IRAM_ATTR handleInterruptAR();
  static void IRAM_ATTR handleInterruptBR();
  static void IRAM_ATTR handleInterruptAL();
  static void IRAM_ATTR handleInterruptBL();
  static void IRAM_ATTR onTimer();
};

#endif // DUAL_ENCODER_H