#include "DualEncoder.h"

DualEncoder* DualEncoder::instance = nullptr;

DualEncoder::DualEncoder(uint8_t pinAR, uint8_t pinBR, uint8_t pinAL, uint8_t pinBL)
  : pinAR(pinAR), pinBR(pinBR), pinAL(pinAL), pinBL(pinBL) {
  instance = this;
}

void DualEncoder::begin() {
  // Right encoder pins
  pinMode(pinAR, INPUT);
  pinMode(pinBR, INPUT);
  attachInterrupt(digitalPinToInterrupt(pinAR), handleInterruptAR, CHANGE);
  attachInterrupt(digitalPinToInterrupt(pinBR), handleInterruptBR, CHANGE);
  
  // Left encoder pins
  pinMode(pinAL, INPUT);
  pinMode(pinBL, INPUT);
  attachInterrupt(digitalPinToInterrupt(pinAL), handleInterruptAL, CHANGE);
  attachInterrupt(digitalPinToInterrupt(pinBL), handleInterruptBL, CHANGE);
  
  // Initialize RPM calculation variables
  lastRpmUpdate = micros();
  lastCountR = 0;
  lastCountL = 0;
}

void DualEncoder::startRpmMeasurement() {
  lastRpmUpdate = micros();
  resetCountR();
  resetCountL();

  // ESP32-S3 Core 3.x Timer setup
  timer = timerBegin(timerNumber);  // Only timer number
  timerAttachInterrupt(timer, &onTimer);  // Only 2 arguments in Core 3.x
  timerAlarm(timer, rpmUpdateInterval, true, rpmUpdateInterval);  // ✅ 4 args required in Core 3.x
}







void DualEncoder::stopRpmMeasurement() {
  if (timer) {
    // Disable alarm by setting autoreload = false and reload_value = 0
    timerAlarm(timer, 0, false, 0);
    timerDetachInterrupt(timer);
    timerEnd(timer);
    timer = nullptr;
  }
}


int32_t DualEncoder::getCountR() {
  noInterrupts();
  int32_t count = encoderCountR;
  interrupts();
  return count;
}

int32_t DualEncoder::getCountL() {
  noInterrupts();
  int32_t count = encoderCountL;
  interrupts();
  return count;
}

void DualEncoder::resetCountR() {
  noInterrupts();
  encoderCountR = 0;
  lastCountR = 0;
  interrupts();
}

void DualEncoder::resetCountL() {
  noInterrupts();
  encoderCountL = 0;
  lastCountL = 0;
  interrupts();
}

float DualEncoder::getRpmR() {
  noInterrupts();
  float rpm = rpmR;
  interrupts();
  return rpm;
}

float DualEncoder::getRpmL() {
  noInterrupts();
  float rpm = rpmL;
  interrupts();
  return rpm;
}

void DualEncoder::updateFromISR(bool isRight, bool isA) {
  if (isRight) {
    bool A = digitalRead(pinAR);
    bool B = digitalRead(pinBR);
    if (isA) {
      if (A != B) encoderCountR++;
      else encoderCountR--;
    } else {
      if (A == B) encoderCountR++;
      else encoderCountR--;
    }
  } else {
    bool A = digitalRead(pinAL);
    bool B = digitalRead(pinBL);
    if (isA) {
      if (A != B) encoderCountL++;
      else encoderCountL--;
    } else {
      if (A == B) encoderCountL++;
      else encoderCountL--;
    }
  }
}

void DualEncoder::calculateRpm() {
  uint32_t currentTime = micros();
  uint32_t elapsedTime = currentTime - lastRpmUpdate;
  lastRpmUpdate = currentTime;
  
  // Prevent division by zero
  if (elapsedTime == 0) return;
  
  // Read current encoder counts (thread-safe)
  noInterrupts();
  int32_t currentCountR = encoderCountR;
  int32_t currentCountL = encoderCountL;
  interrupts();
  
  // Calculate count differences
  int32_t countDiffR = currentCountR - lastCountR;
  int32_t countDiffL = currentCountL - lastCountL;
  
  // Calculate counts per revolution (based on gear ratio and encoder CPR)
  uint32_t countsPerRev = gearRatio * encoderCPR;
  
  // Calculate RPM
  // Formula: (count_diff * 60 * 1000000) / (elapsed_time_micros * counts_per_revolution)
  noInterrupts();
  rpmR = (countDiffR * 60.0f * 1000000.0f) / (elapsedTime * countsPerRev);
  rpmL = (countDiffL * 60.0f * 1000000.0f) / (elapsedTime * countsPerRev);
  
  // Store current counts for next calculation
  lastCountR = currentCountR;
  lastCountL = currentCountL;
  interrupts();
}

// Static ISR wrappers
void IRAM_ATTR DualEncoder::handleInterruptAR() {
  if (instance) instance->updateFromISR(true, true);
}

void IRAM_ATTR DualEncoder::handleInterruptBR() {
  if (instance) instance->updateFromISR(true, false);
}

void IRAM_ATTR DualEncoder::handleInterruptAL() {
  if (instance) instance->updateFromISR(false, true);
}

void IRAM_ATTR DualEncoder::handleInterruptBL() {
  if (instance) instance->updateFromISR(false, false);
}

void IRAM_ATTR DualEncoder::onTimer() {
  if (instance) {
    instance->calculateRpm();
  }
}